﻿using Editorial.Domain.EntityModels;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Editorial.Application.Contracts.DbContexts
{
    public interface IApplicationDbContext
    {
        DbSet<Autor> Autores { get; set; }

        DbSet<Categoria> Categorias { get; set; }

        DbSet<Libro> Libros { get; set; }
    }
}
