﻿using Editorial.Application.Contracts.DbContexts;
using Editorial.Application.Contracts.Repositories;
using Editorial.Application.Contracts.Services;
using Editorial.Domain.EntityModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;

namespace Editorial.Application.Services
{
    public class CategoriaService : ICategoriaService
    { 
        public CategoriaService
            (ICategoriaRepository repository)
        {
            _repository = repository;
        }
        readonly ICategoriaRepository _repository;

        public Categoria Get(int id)
        {
           return _repository.Get(s => s.Id == id);
        }

        public IEnumerable<Categoria> List (Expression<Func<Categoria, bool>> predicate = null)
        {
            return _repository.GetAll(predicate);
        }

        public void Insert(Categoria categoria)
        {
            _repository.Insert(categoria);
            _repository.Save();
        }

        public void Update(Categoria categoria)
        {
            if (categoria == null)
            {
                throw new ArgumentNullException(nameof(categoria));
            }

            _repository.Update(categoria);
            _repository.Save();
        }

        public void Delete(Categoria categoria)
        {
            if (categoria == null)
            {
                throw new ArgumentNullException(nameof(categoria));
            }

            _repository.Delete(categoria);
            _repository.Save();
        }

        public void Delete(int id)
        {
            Delete(Get(id));
        }
    }
}
