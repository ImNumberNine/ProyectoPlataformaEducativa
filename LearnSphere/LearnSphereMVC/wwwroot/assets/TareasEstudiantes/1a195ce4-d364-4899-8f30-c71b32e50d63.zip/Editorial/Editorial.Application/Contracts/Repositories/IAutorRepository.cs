﻿using Editorial.Application.Contracts.DbContexts;
using Editorial.Domain.EntityModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Editorial.Application.Contracts.Repositories
{
    public interface IAutorRepository : IRepository<Autor>
    {
    }
}
