﻿using Editorial.Domain.EntityModels;
using Microsoft.EntityFrameworkCore.Migrations.Operations;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;

namespace Editorial.Application.Contracts.Services
{
    public interface ICategoriaService
    {
        Categoria Get(int id);

        IEnumerable<Categoria> List(Expression<Func<Categoria, bool>> predicate = null);

        void Insert(Categoria categoria);

        void Update(Categoria categoria);

        void Delete(Categoria categoria);

        void Delete(int id);

    }
}
