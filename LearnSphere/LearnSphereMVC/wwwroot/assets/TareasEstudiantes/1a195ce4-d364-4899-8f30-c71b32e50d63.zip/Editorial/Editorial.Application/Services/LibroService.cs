﻿using Editorial.Application.Contracts.DbContexts;
using Editorial.Application.Contracts.Repositories;
using Editorial.Application.Contracts.Services;
using Editorial.Domain.EntityModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;

namespace Editorial.Application.Services
{
    public class LibroService : ILibroService
    { 
        public LibroService
            (ILibroRepository repository)
        {
            _repository = repository;
        }
        readonly ILibroRepository _repository;

        public Libro Get(int id)
        {
           return _repository.Get(s => s.Id == id);
        }

        public IEnumerable<Libro> List (Expression<Func<Libro, bool>> predicate = null)
        {
            return _repository.GetAll(predicate);
        }

        public void Insert(Libro libro)
        {
            _repository.Insert(libro);
            _repository.Save();
        }

        public void Update(Libro libro)
        {
            if (libro == null)
            {
                throw new ArgumentNullException(nameof(libro));
            }

            _repository.Update(libro);
            _repository.Save();
        }

        public void Delete(Libro libro)
        {
            if (libro == null)
            {
                throw new ArgumentNullException(nameof(libro));
            }

            _repository.Delete(libro);
            _repository.Save();
        }

        public void Delete(int id)
        {
            Delete(Get(id));
        }
    }
}
