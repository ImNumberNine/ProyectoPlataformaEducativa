﻿using Editorial.Domain.EntityModels;
using Microsoft.EntityFrameworkCore.Migrations.Operations;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;

namespace Editorial.Application.Contracts.Services
{
    public interface ILibroService
    {
        Libro Get(int id);

        IEnumerable<Libro> List(Expression<Func<Libro, bool>> predicate = null);

        void Insert(Libro libro);

        void Update(Libro libro);

        void Delete(Libro libro);

        void Delete(int id);

    }
}
