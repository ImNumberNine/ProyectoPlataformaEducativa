﻿using Editorial.Application.Contracts.DbContexts;
using Editorial.Application.Contracts.Repositories;
using Editorial.Application.Contracts.Services;
using Editorial.Application.Services;
using Editorial.Domain.EntityModels;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Editorial.Application
{
    public static class injection
    {
        public static IServiceCollection AddApplicationServices
           (this IServiceCollection services,
           IConfiguration configuration)
        {
            services.AddScoped<IAutorService, AutorService>();
            services.AddScoped<ICategoriaService, CategoriaService>();
            services.AddScoped<ILibroService, LibroService>();
            return services;
        }
    }
}
