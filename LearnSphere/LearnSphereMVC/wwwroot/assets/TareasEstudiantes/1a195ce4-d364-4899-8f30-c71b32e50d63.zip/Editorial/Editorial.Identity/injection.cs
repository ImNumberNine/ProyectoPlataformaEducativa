﻿using Editorial.Application.Contracts.DbContexts;
using Editorial.Application.Contracts.Identity;
using Editorial.Application.Contracts.Repositories;
using Editorial.Domain.EntityModels;
using Editorial.Domain.EntityModels.Identity;
using Editorial.Identity.DbContexts;
using Editorial.Identity.Services;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Editorial.Persistence
{
    public static class injection
    {
        public static IServiceCollection AddIdentityServices
            (this IServiceCollection services,
            IConfiguration configuration)
        {
            services.AddDbContextPool<ApplicationIdentityDbContext>(options =>
            {
                options.UseSqlServer(configuration.GetConnectionString("DefaultConnection"));
            });

            services.AddIdentity<Usuario, IdentityRole>(options =>
            {
                options.Password.RequiredLength = 10;
                options.Password.RequiredUniqueChars = 3;
            }).AddEntityFrameworkStores<ApplicationIdentityDbContext>();

            services.AddScoped<IAccountService, AccountService>();

            return services;
        }
    }
}
