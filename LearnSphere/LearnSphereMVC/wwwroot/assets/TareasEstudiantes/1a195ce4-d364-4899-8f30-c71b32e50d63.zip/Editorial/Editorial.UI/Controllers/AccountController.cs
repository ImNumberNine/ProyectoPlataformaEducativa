﻿using Editorial.Application.Contracts.Identity;
using Editorial.Domain.InputModels;
using Microsoft.AspNetCore.Mvc;

namespace Editorial.UI.Controllers
{
    public class AccountController : Controller
    {

        public AccountController(IAccountService service)
        {
            _service = service;
        }

        private readonly IAccountService _service;

        [HttpGet]
        public IActionResult Register()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> Register(Register Model)
        {
            if (ModelState.IsValid)
            {
                try
                {
                    await _service.Register(Model.Email, Model.Password);
                }
                catch(Exception ex)
                {
                    ModelState.AddModelError("", ex.Message);
                }
                return RedirectToAction("Home","Index");
            }
            return View(Model);
        }
    }
}
