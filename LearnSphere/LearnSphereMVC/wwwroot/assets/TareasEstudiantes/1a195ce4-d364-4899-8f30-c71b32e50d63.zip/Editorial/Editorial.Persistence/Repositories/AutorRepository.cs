﻿using Editorial.Application.Contracts.Repositories;
using Editorial.Domain.EntityModels;
using Editorial.Persistence.DbContexts;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Editorial.Persistence.Repositories
{
    public class AutorRepository : Repository<Autor>,
        IAutorRepository
    {
        public AutorRepository(ApplicationDbContext context) 
            : base(context)
        {
        }
    }
}
