﻿using Editorial.Application.Contracts.Repositories;
using Editorial.Domain.EntityModels;
using Editorial.Persistence.DbContexts;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Editorial.Persistence.Repositories
{
    public class CategoriaRepository : Repository<Categoria>,
        ICategoriaRepository
    {
        public CategoriaRepository(ApplicationDbContext context) 
            : base(context)
        {
        }
    }
}
