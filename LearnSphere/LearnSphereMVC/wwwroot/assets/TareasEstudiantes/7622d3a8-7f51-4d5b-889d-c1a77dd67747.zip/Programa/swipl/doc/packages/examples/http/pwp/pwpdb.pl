%  This is a tiny data base for testing PWP.

msg('Hello, World!').

status(tom,   full_time).
status(dick,  part_time).
status(harry, full_time).

staff(tom,   'Tom Cat',    1-21, 'x1234', 'tom@jerry.example.org').
staff(dick,  'Dick Tater', 2-50, 'x9999', 'boss@hq.example.org').
staff(harry, 'Harry Ett',  3-14, 'x7654', 'h.ett@kit.example.org').

