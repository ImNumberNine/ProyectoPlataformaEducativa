﻿using Editorial.Application.Contracts.DbContexts;
using Editorial.Domain.EntityModels.Identity;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Editorial.Identity.DbContexts
{
    public class ApplicationIdentityDbContext 
        : IdentityDbContext<Usuario>, IApplicationIdentityDbContext
    {
        public ApplicationIdentityDbContext
            (DbContextOptions<ApplicationIdentityDbContext> options)
                :base(options) 
        {
            
        }

        public DbSet<Permiso> Permisos { get; set; }

        public DbSet<Usuario> Usuarios { get; set; }
    }
}
