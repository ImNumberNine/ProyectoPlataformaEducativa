﻿using Editorial.Application.Contracts.DbContexts;
using Editorial.Application.Contracts.Identity;
using Editorial.Application.Contracts.Repositories;
using Editorial.Domain.EntityModels;
using Editorial.Domain.EntityModels.Identity;
using Editorial.Identity.DbContexts;
using Editorial.Identity.Services;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Editorial.Identity
{
    public static class Injection
    {
        public static IServiceCollection AddIdentityServices
            (this IServiceCollection services, IConfiguration configuration)
        {
            services.AddDbContextPool<ApplicationIdentityDbContext>(options =>
            {
                options.UseSqlServer(
                    configuration.GetConnectionString("DefaultConnection"));
            });

            services.AddIdentity<Usuario, IdentityRole>(options =>
            {
                options.Password.RequiredLength = 10;
                options.Password.RequiredUniqueChars = 3;
            }).AddEntityFrameworkStores<ApplicationIdentityDbContext>().AddDefaultTokenProviders();

            services.AddAuthentication(options =>
            {
                options.DefaultAuthenticateScheme = IdentityConstants.ApplicationScheme;
                options.DefaultChallengeScheme = IdentityConstants.ApplicationScheme;
                options.DefaultSignInScheme = IdentityConstants.ExternalScheme;
            }).AddGoogle(options => 
                {
                    options.ClientId = "59200733309-l0qr7ql9om56goeiu92r43b5ak32l346.apps.googleusercontent.com";
                    options.ClientSecret = "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";
                    
                    // options.CallbackPath = "/Account/ExternalLoginCallback";
                });

            services.AddScoped<IAccountService, AccountService>();

            return services;
        }
    }
}
