﻿using Editorial.Domain.EntityModels.Identity;
using Editorial.Identity.DbContexts;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Editorial.Identity.Attributes
{
    [AttributeUsage(AttributeTargets.Class | AttributeTargets.Method, AllowMultiple = true, Inherited = true)]
    public class EnhancedAuthorizeAttribute : Attribute, IAuthorizationFilter
    {
        public EnhancedAuthorizeAttribute(string section)
        {
            this._section = section.ToLower().Trim();
        }

        private readonly string _section;

        void IAuthorizationFilter.OnAuthorization(AuthorizationFilterContext filterContext)
        {
            bool skipAuthorization = filterContext.ActionDescriptor.EndpointMetadata.OfType<AllowAnonymousAttribute>().Any();

            if (skipAuthorization)
            {
                return;
            }

            var username = filterContext.HttpContext.User.Identity.Name;
            if (username == null)
            {
                filterContext.Result = new StatusCodeResult(401);
                return;
            }

            var dbContext = filterContext.HttpContext.RequestServices
               .GetService(typeof(ApplicationIdentityDbContext))
                   as ApplicationIdentityDbContext;

            IQueryable<Usuario> query = dbContext.Usuarios;
            query.Include(i => i.Permisos);

            Usuario usuario = query.Where(w => w.UserName.ToLower() == username.ToLower()).FirstOrDefault();
            Permiso permiso = usuario.Permisos.FirstOrDefault(s => s.Nombre.ToLower() == _section);

            if (permiso == null)
            {
                filterContext.Result = new StatusCodeResult(401);
                return;
            }

            bool hasPermission = permiso.Usuarios.Where(w => w.UserName == username).Any();

            //bool hasPermission = dbContext.Permisos.Where(w => w.Nombre.ToLower() == _section).FirstOrDefault().Usuarios.Where(w => w.UserName == username).Any();

            if (!hasPermission)
            {
                filterContext.Result = new StatusCodeResult(401);
            }
        }
    }
}
