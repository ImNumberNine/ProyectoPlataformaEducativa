﻿using Editorial.Application.Contracts.Services;
using Editorial.Application.Services;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Editorial.Application
{
    public static class Injection
    {
        public static IServiceCollection AddApplicationServices
            (this IServiceCollection services,
                IConfiguration configuration)
        {
            services.AddScoped<IAutorService, AutorService>();
            return services;
        }
    }
}
