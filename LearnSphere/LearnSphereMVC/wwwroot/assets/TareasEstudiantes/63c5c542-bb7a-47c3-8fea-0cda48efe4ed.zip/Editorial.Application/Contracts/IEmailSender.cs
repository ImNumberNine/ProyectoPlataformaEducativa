﻿using Editorial.Domain.ComponentModels;

namespace Editorial.Application.Contracts
{
    public interface IEmailSender 
    {
        void Send(Email email);
    }
}
