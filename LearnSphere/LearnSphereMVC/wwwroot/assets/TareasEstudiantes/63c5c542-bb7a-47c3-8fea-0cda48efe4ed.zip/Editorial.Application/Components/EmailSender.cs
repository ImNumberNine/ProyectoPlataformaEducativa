﻿using Editorial.Application.Contracts;
using Editorial.Domain.ComponentModels;
using Editorial.Domain.ConfigurationModels;
using Microsoft.Extensions.Options;
using System.Net;
using System.Net.Mail;

namespace Editorial.Application.Components
{
    public class EmailSender : IEmailSender
    {
        //public emailsender(iconfiguration configuration)
        //{
        //    configuration = configuration;
        //    smtpconfiguration = configuration.getsection("smtpconfiguration").get<smtpconfiguration>();
        //}

        //readonly iconfiguration configuration;

        readonly SmtpConfiguration SmtpConfiguration;

        public EmailSender(IOptions<SmtpConfiguration> smtpConfiguration)
        {
            SmtpConfiguration = smtpConfiguration.Value;
        }
        public void Send(Email email)
        {
            //Configura el cliente que se conecta al servidor SMTP
            var client = new SmtpClient
            {
                Host = SmtpConfiguration.Server,
                Port = SmtpConfiguration.Port,
                EnableSsl = true,
                UseDefaultCredentials = false,
                Credentials = new NetworkCredential(SmtpConfiguration.UserName, SmtpConfiguration.Password)
            };

            //crea el cuerpo del correo electronico
            var message = new MailMessage
            {
                From = new MailAddress(SmtpConfiguration.Sender),
                Subject = email.Subject,
                Body = email.Body
            };

            message.To.Add(new MailAddress(email.Recipient));

            //envia el correo
            client.Send(message);
        }
    }
}
