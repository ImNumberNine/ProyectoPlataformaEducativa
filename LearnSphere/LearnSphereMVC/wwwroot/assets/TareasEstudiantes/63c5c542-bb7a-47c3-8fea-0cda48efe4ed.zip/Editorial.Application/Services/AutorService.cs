﻿using Editorial.Application.Contracts.DbContexts;
using Editorial.Application.Contracts.Repositories;
using Editorial.Application.Contracts.Services;
using Editorial.Domain.EntityModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;

namespace Editorial.Application.Services
{
    public class AutorService : IAutorService
    {
        public AutorService(IAutorRepository repository)
        {
            _repository = repository;
        }

        readonly IAutorRepository _repository;

        public Autor Get(int id)
        {
            return _repository.Get(s => s.Id == id);
        }

        public IEnumerable<Autor> List
            (Expression<Func<Autor, bool>> predicate = null)
        {
            return _repository.GetAll(predicate);
        }

        public void Insert(Autor autor)
        {
            _repository.Insert(autor);
            _repository.Save();
        }

        public void Update(Autor autor)
        {
            if (autor == null)
            {
                throw new ArgumentNullException(nameof(autor));
            }

            _repository.Update(autor);
            _repository.Save();
        }

        public void Delete(int id)
        {
            Delete(Get(id));
        }

        public void Delete(Autor autor)
        {
            if (autor == null)
            { 
                throw new ArgumentNullException(nameof(autor));
            }

            _repository.Delete(autor);
            _repository.Save();
        }
    }
}
