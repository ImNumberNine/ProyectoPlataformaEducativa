﻿using Editorial.Application.Contracts;
using Editorial.Application.Contracts.Identity;
using Editorial.Application.Contracts.Recaptcha;
using Editorial.Domain.ComponentModels;
using Editorial.Domain.InputModels;
using Editorial.Identity.Attributes;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore.Metadata.Internal;
using System.Reflection.Metadata.Ecma335;

namespace Editorial.UI.Controllers
{
    [EnhancedAuthorize("Account")]
    public class AccountController : Controller
    {
        public AccountController
            (IAccountService service, IGoogleRecaptchaService recaptchaService, IEmailSender emailSender)
        {
            _service = service;
            _recaptchaService = recaptchaService;
            _emailSender = emailSender;
        }

        readonly IAccountService _service;
        readonly IGoogleRecaptchaService _recaptchaService;
        readonly IEmailSender _emailSender;

        [HttpGet]
        [AllowAnonymous]
        public async Task<IActionResult> Register()
        {
            var model = new RegisterInputModel
            {
                ExternalLogins = (await _service.ListExternalLogins()).ToList()
            };
            return View(model);
        }

        [HttpPost]
        [AllowAnonymous]
        public async Task<IActionResult> Register(RegisterInputModel model)
        {
            if (ModelState.IsValid)
            {
                try
                { await _service.Register(model.Email, model.Password); }
                catch (Exception ex)
                {
                    ModelState.AddModelError("", ex.Message);
                }

                return RedirectToAction("Index", "Home");
            }

            return View(model);
        }

        [HttpGet]
        [AllowAnonymous]
        public async Task<IActionResult> Login()
        {
            var model = new LoginInputModel
            {
                ExternalLogins = (await _service.ListExternalLogins()).ToList()
            };
            return View(model);
        }


        [HttpPost]
        [AllowAnonymous]
        public async Task<IActionResult> Login(LoginInputModel model)
        {
            model.ExternalLogins = (await _service.ListExternalLogins()).ToList();

            var recaptchaResult = await _recaptchaService.VerifyToken(model.Token);

            if (recaptchaResult)
            {
                await _service.Login(model.Email, model.Password);
                return RedirectToAction("Index", "Home");
            }

            return View(model);
        }

        [HttpGet]
        [AllowAnonymous]
        public async Task<IActionResult> Logout()
        {
            await _service.Logout();
            return RedirectToAction("Index", "Home");
        }

        [AllowAnonymous]
        [HttpPost]
        public IActionResult ExternalLogin(string provider, string returnUrl)
        {
            var redirectUrl =
                Url.Action("ExternalLoginCallback", "Account",
                    new { ReturnUrl = returnUrl });

            var properties =
                _service.ConfigureExternalLogin(provider, redirectUrl);

            return new ChallengeResult(provider, properties);
        }

        [AllowAnonymous]
        [Route("signin-google")]
        [Route("[controller]/[action]")]
        public async Task<IActionResult> ExternalLoginCallback
            (string returnUrl = null, string remoteError = null)
        {
            if (string.IsNullOrEmpty(returnUrl))
                returnUrl = "~/";

            var model = new RegisterInputModel
            {
                ReturnUrl = returnUrl,
                ExternalLogins = (await _service.ListExternalLogins()).ToList()
            };

            if (!string.IsNullOrEmpty(remoteError))
            {
                ModelState.AddModelError
                    ("", $"Error from external provider: {remoteError}");
                return View(nameof(Register), model);
            }

            var info = await _service.GetExternalLoginInfo();
            if (info == null)
            {
                ModelState.AddModelError
                    ("", "Error loading external login information.");
                return View(nameof(Register), model);
            }

            if (!await _service.RegisterExternalLogin(info))
            {
                ModelState.AddModelError
                    ("", "Error registering external login information.");
                return View(nameof(Register), model);
            }

            return LocalRedirect(returnUrl);
        }

        [HttpGet]
        [AllowAnonymous]
        public async Task<IActionResult> ChangePassword()
        {
            var model = new ChangePasswordModel
            {
                ExternalLogins = (await _service.ListExternalLogins()).ToList()
            };
            return View(model);
        }

        [HttpPost]
        [AllowAnonymous]
        public async Task<IActionResult> ChangePassword(ChangePasswordModel model)
        {
            if (ModelState.IsValid)
            {
                await _service.ChangePassword(model.Email, model.OldPasword, model.NewPassword);
                return RedirectToAction("Index", "Home");
            }
            return View(model);
        }

        [HttpGet]
        [AllowAnonymous]
        public async Task<IActionResult> GetForgotPasswordToken()
        {
            var model = new GetForgotPasswordToken
            {
                ExternalLogins = (await _service.ListExternalLogins()).ToList()
            };
            return View(model);
        }

        [HttpPost]
        [AllowAnonymous]
        public async Task<IActionResult> GetForgotPasswordToken(GetForgotPasswordToken model)
        {
            if (ModelState.IsValid)
            {
                string token = await _service.GetForgotPasswordToken(model.Email);

                Email email = new Email
                {
                    Recipient = model.Email,
                    Subject = "Password Recovery",
                    Body = "Please click the next link in order to recover your password " + "https://localhost:7133/Account/ResetPassword?EMAIL="+model.Email+"&TOKEN="+token
                };

                //var emailSender = new EmailSender(_configuration);
                //emailSender.Send(email);

                _emailSender.Send(email);

                return RedirectToAction("Index", "Home");
            }
            return View(model);
        }

        [HttpGet]
        [AllowAnonymous]
        public async Task<IActionResult> ResetPassword(string email, string token)
        {
            var model = new ResetPassword
            {
                Email = email,
                Token = token,
                ExternalLogins = (await _service.ListExternalLogins()).ToList()
            };
            
            return View(model);
        }

        [HttpPost]
        [AllowAnonymous]
        public async Task<IActionResult> ResetPassword(ResetPassword model, string email, string token)
        {
            if (ModelState.IsValid)
            {
                model.Token = model.Token.Replace(' ', '+');
                await _service.ResetPassword(model.Email, model.Token, model.NewPassword);
                
                return RedirectToAction("Index", "Home");
            }
            return View(model);
        }
    }
}
